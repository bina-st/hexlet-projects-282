import telegram
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, ConversationHandler
from telegram import ReplyKeyboardMarkup, ReplyKeyboardRemove
import logging
import json
import random
import os

TOKEN='токен бота'

START, NAME, CHOOSING_ACTION, LESSON, REPEAT, TEST = range(6)
USER_DATA_FILE = 'user_data.json'
WORD_DATA_FILE = 'words.json'

def load_data(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f'Файл {filepath} не найден')
        return {}
    except json.JSONDecodeError:
        print(f'Ошибка при чтении файла {filepath}')
        return {}

def save_data(data, filepath):
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)


user_data = load_data(USER_DATA_FILE)
word_data = load_data(WORD_DATA_FILE)

def start(update, context):
    pass


def name(update, context):
    pass


def lesson(update, context):
    pass


def repeat(update, context):
    pass


def test(update, context):
    pass


def handle_answer(update, context):
    pass


def help_command(update, context):
    pass


def handle_choice(update, context):
    text = update.message.text
    if text == 'Урок':
        return lesson(update, context)
    elif text == 'Повторение':
        return repeat(update, context)
    elif text == 'Тест':
        return test(update, context)
    elif text == 'Помощь':
        return help_command(update, context)
    else:
        update.message.reply_text('Пожалуйста, выберите действие из меню')
        return CHOOSING_ACTION


def unknown(update, context):
    update.message.reply_text(
        'Я не понимаю эту команду. Используй /help для списка команд')

def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states={
            NAME: [MessageHandler(Filters.text & ~Filters.command, name)],
            CHOOSING_ACTION: [MessageHandler(Filters.regex(
                '^(Урок|Повторение|Тест|Помощь)$'), handle_choice)],
            TEST: [MessageHandler(Filters.text & ~Filters.command, handle_answer),
                   CommandHandler('start', start)],},
        fallbacks=[CommandHandler('start', start)],)
    dp.add_handler(conv_handler)
    dp.add_handler(CommandHandler('help', help_command))
    dp.add_handler(MessageHandler(Filters.command, unknown))

    updater.start_polling()
    updater.idle()

if name=='main':
    main()