import telegram
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
from telegram import ReplyKeyboardMarkup
import logging
import json
from datetime import datetime

with open('info.json', 'r', encoding='utf-8') as file:
    info = json.load(file)

TOKEN = ''
logging.basicConfig(
    format='%(asctime)s-%(name)s-%(levelname)s-%(message)s',
    level=logging.INFO)

keyboard = [
    ['Начать','О курсе'],
    ['Темы курса','Осталось времени'],
    ['Помощь']
]
reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def start(update, context):
    update.message.reply_text('Привет человек! Выбери команду:',
                              reply_markup = reply_markup)

def about(update, context):
    description = info['description']
    update.message.reply_text(f'О курсе: {description}',
                              reply_markup = reply_markup)

def topics(update, context):
    topics_list="\n".join(info['topics'])
    update.message.reply_text(f'Содержание: \n{topics_list}',
                              reply_markup = reply_markup)

def time_left(update, context):
    end_date=datetime.strptime(info['end_date'],'%Y-%m-%d')
    today = datetime.now()
    weeks_left=(end_date-today).days//7
    update.message.reply_text(f'Осталось {weeks_left} занятий',
                              reply_markup = reply_markup)

def help(update, context):
    help_text = '''
    Доступные команды:
    /start - Начать работу
    /about - Информация о курсе
    /topics - Содержание курса
    /time_left - Время до конца курса
    /help - Список команд
    '''
    update.message.reply_text(help_text,
                              reply_markup = reply_markup)

def handle_message(update, context):
    text = update.message.text
    if text=='Начать':
        start(update, context)
    elif text=='О курсе':
        about(update, context)
    elif text=='Темы курса':
        topics(update, context)
    elif text=='Осталось времени':
        time_left(update, context)
    elif text=='Помощь':
        help(update, context)
    else:
        update.message.reply_text('Я не понимаю эту команду',
                                  reply_markup=reply_markup)

def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start",start))
    dp.add_handler(CommandHandler("about", about))
    dp.add_handler(CommandHandler("topics", topics))
    dp.add_handler(CommandHandler("time_left", time_left))
    dp.add_handler(CommandHandler("help", help))

    dp.add_handler(MessageHandler(Filters.text&~Filters.command,
                                  handle_message))
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
