from fnmatch import translate
from gettext import translation

import telebot
import json
import random
from telebot.types import ReplyKeyboardMarkup, ReplyKeyboardRemove

from lang_bot import handle_answer
from main import reply_markup

TOKEN = 'token'
bot = telebot.TeleBot(TOKEN)

USER_DATA_FILE = 'user_data.json'
WORD_DATA_FILE = 'words.json'

def load_data(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f'Файл {filepath} не найден')
        return {}
    except json.JSONDecodeError:
        print(f'Ошибка при чтении файла {filepath}')
        return {}

def save_data(data, filepath):
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)


user_data = load_data(USER_DATA_FILE)
word_data = load_data(WORD_DATA_FILE)

def name(m):
    user_id = m.from_user.id
    user_name = m.text
    user_data[user_id] = {'name': user_name, 'learned_words':[], 'level':'beginner'}
    save_data(user_data, USER_DATA_FILE)
    reply_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    reply_keyboard.row('Урок', "Повторение")
    reply_keyboard.row('Тест', "Помощь")
    bot.send_message(m.chat.id, 'Приятно познакомиться, теперь вы можете начать изучать английский!')

@bot.message_handler(commands=['start'])
def start(m):
    user_id = m.from_user.id
    if user_id not in user_data:
        bot.send_message(m.chat.id,
'Привет! Я бот для изучения английского. Как я могу к вам обращаться?')
        bot.register_next_step_handler(m, name)
    else:
        user_name = user_data[user_id]['name']
        reply_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
        reply_keyboard.row('Урок', "Повторение")
        reply_keyboard.row('Тест', "Помощь")
        bot.send_message(m.chat.id, f'Рады вас снова видеть {user_name} :)', reply_markup=reply_keyboard)

@bot.message_handler(func=lambda m: m.text == 'Урок')
def lesson(m):
    user_id = m.from_user.id
    if not word_data:
        bot.send_message(m.chat.id, 'Словарь пуст! Добавьте слова')
        return
    word, details = random.choice(list(word_data.items()))
    translation = details['translation']
    example = details['example']

    message_text = f'Слово: {word}\nПеревод: {translation} \nПример:{example}'
    bot.send_message(m.chat.id, message_text,
                     reply_markup=ReplyKeyboardRemove())

    if user_id not in user_data:
        user_data[user_id] = {'name':'Unknown', 'learned_words':[],
                              'level':'beginner'}
    user_data[user_id]['learned_words'].append(word)
    save_data(user_data, USER_DATA_FILE)
    reply_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    reply_keyboard.row('Урок', "Повторение")
    reply_keyboard.row('Тест', "Помощь")
    bot.send_message(m.chat.id, 'Что дальше?',
                     reply_markup=reply_keyboard)


@bot.message_handler(func=lambda m: m.text == 'Повторение')
def repeat(m):
    user_id = m.from_user.id
    if not user_data.get(user_id) or not user_data[user_id]['learned_words']:
        bot.send_message(m.chat.id, 'Вы еще не изучили ни одного слова!')
        return
    word = random.choice(user_data[user_id]['learned_words'])
    details = word_data.get(word)
    if details:
        translation = details['translation']
        bot.send_message(m.chat.id, f'Повторите слово: {word}.\n '
                    f'Перевод:{translation}', reply_markup=ReplyKeyboardRemove())
    else:
        bot.send_message(m.chat.id, 'Произошла ошибка',
                         reply_markup=ReplyKeyboardRemove())
    reply_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    reply_keyboard.row('Урок', "Повторение")
    reply_keyboard.row('Тест', "Помощь")
    bot.send_message(m.chat.id, 'Что дальше?',
                     reply_markup=reply_keyboard)

@bot.message_handler(func=lambda m: m.text == 'Тест')
def test(m):
    user_id = m.from_user.id
    if not user_data.get(user_id) or not user_data[user_id]['learned_words']:
        bot.send_message(m.chat.id, 'Вы еще не изучили ни одного слова')
        return
    word = random.choice(user_data[user_id]['learned_words'])
    correct_translation = word_data[word]['translation']
    incorrect_translations = [word_data[w]['translation']
                              for w in random.sample(
            list(word_data.keys()), 3) if w != word]
    options = incorrect_translations + [correct_translation]
    random.shuffle(options)
    reply_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    for option in options:
        reply_keyboard.row(option)
    bot.send_message(m.chat.id, f'Выберите перевод слова: {word}',
                     reply_markup= reply_keyboard)
    bot.register_next_step_handler(m, handle_answer, word)


def handle_answer(m, word):
    user_answer = m.text
    correct_translation = word_data[word]['translation']
    if user_answer == correct_translation:
        bot.send_message(m.chat.id, 'Правильно!')
    else:
        bot.send_message(m.chat.id,
                         f'Не правильно, {correct_translation}')
    reply_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    reply_keyboard.row('Урок', "Повторение")
    reply_keyboard.row('Тест', "Помощь")
    bot.send_message(m.chat.id, 'Что дальше?',
                     reply_markup=reply_keyboard)

@bot.message_handler(func=lambda m: m.text == 'Помощь')
def help(m):
    help_text= '''
    Доступные команды:
    /start - перезапуск бота
    Урок - получить новое слово
    Повторение - повторить изученные слова
    Тест - пройти тест
    Помощь - показать эту справку
    '''
    bot.send_message(m.chat.id, help_text)
    reply_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    reply_keyboard.row('Урок', "Повторение")
    reply_keyboard.row('Тест', "Помощь")
    bot.send_message(m.chat.id, 'Что дальше?',
                     reply_markup=reply_keyboard)

@bot.message_handler(func=lambda m: True)
def unknown(m):
    bot.send_message(m.chat.id, 'Я не понимаю эту команду. /help для справки')











bot.polling(none_stop=True)